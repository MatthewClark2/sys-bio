# 
#  This file has to be sourced before activating AUTO2000 is you are using
#  a 'sh' compatible shell, such as sh, bash, ksh, or ash.
#
AUTO_DIR=/Users/mlamar/Documents/Research/PyDSTool/PyCont/auto
PATH=$AUTO_DIR/cmds:$AUTO_DIR/bin:$PATH
export AUTO_DIR
export PATH
#
# DON'T ADD ANYTHING AFTER THIS LINE
#
