"""Toolbox utilities for applications.

   Robert Clewley, October 2005
"""

