double signum(double x);
