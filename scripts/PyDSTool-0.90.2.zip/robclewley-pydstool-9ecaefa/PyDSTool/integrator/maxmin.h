#include <stdlib.h>
#include <stdarg.h>

double maxof(int, ...);
double minof(int, ...);