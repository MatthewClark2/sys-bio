#!/usr/bin/env python
# -*- coding: utf-8 -*-

from PyDSTool.Toolbox import DSSRT_tools as dst


def test_smoke():
    assert dst.__doc__
