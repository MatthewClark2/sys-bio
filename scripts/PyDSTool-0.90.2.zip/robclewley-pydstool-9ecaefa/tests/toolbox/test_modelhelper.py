#!/usr/bin/env python
# -*- coding: utf-8 -*-

from PyDSTool.Toolbox import ModelHelper as mh


def test_smoke():
    assert mh.__doc__



