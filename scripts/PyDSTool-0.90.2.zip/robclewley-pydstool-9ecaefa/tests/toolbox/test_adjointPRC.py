#!/usr/bin/env python
# -*- coding: utf-8 -*-

from PyDSTool.Toolbox import adjointPRC

def test_smoke():
    assert not adjointPRC.__doc__
