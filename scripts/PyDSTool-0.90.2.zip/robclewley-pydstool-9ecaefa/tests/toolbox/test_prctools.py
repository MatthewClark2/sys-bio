#!/usr/bin/env python
# -*- coding: utf-8 -*-

from PyDSTool.Toolbox import PRCtools as prc


def test_smoke():
    assert prc.__doc__
