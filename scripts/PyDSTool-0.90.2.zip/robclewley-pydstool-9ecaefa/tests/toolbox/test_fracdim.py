#!/usr/bin/env python
# -*- coding: utf-8 -*-

from PyDSTool.Toolbox import fracdim as fd


def test_smoke():
    assert fd.__doc__
