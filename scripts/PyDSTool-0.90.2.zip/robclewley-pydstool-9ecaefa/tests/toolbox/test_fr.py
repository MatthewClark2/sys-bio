#!/usr/bin/env python
# -*- coding: utf-8 -*-

from PyDSTool.Toolbox import FR as fr


def test_smoke():
    assert not fr.__doc__
