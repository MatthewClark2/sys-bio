#!/usr/bin/env python
# -*- coding: utf-8 -*-

from PyDSTool.Toolbox import neuralcomp as nc


def test_smoke():
    assert nc.__doc__
