#!/usr/bin/env python
# -*- coding: utf-8 -*-

from PyDSTool.Toolbox import FSM as fsm


def test_smoke():
    assert fsm.__doc__
