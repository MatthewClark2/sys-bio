#!/usr/bin/env python
# -*- coding: utf-8 -*-

from PyDSTool.Toolbox import phaseplane as pp


def test_smoke():
    assert pp.__doc__
